from geometry.shape import Shape
from geometry.circle import Circle
from geometry.rectangle import Rectangle
from geometry.square import Square
