from geometry import Circle, Rectangle, Square


def show_shapes(shapes):
    for shape in shapes:
        shape.show_info()
        print()


if __name__ == "__main__":
    circle = Circle(5)
    rectangle = Rectangle(4, 6)
    square = Square(3)

    shapes = [circle, rectangle, square]

    print("FIGURY GEOMETRYCZNE")
    print()

    show_shapes(shapes)

    print("ZMIANA PROMIENIA KOŁA")
    circle.radius = 10
    circle.show_info()

    print()

    print("ZMIANA BOKU KWADRATU")
    square.side = 8
    square.show_info()
