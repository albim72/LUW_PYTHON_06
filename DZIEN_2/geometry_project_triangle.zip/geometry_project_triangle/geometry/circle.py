import math

from geometry.shape import Shape


class Circle(Shape):
    def __init__(self, radius):
        super().__init__("Koło")
        self.radius = radius

    @property
    def radius(self):
        return self._radius

    @radius.setter
    def radius(self, value):
        if value <= 0:
            raise ValueError("Promień musi być większy od zera.")
        self._radius = value

    def area(self):
        return math.pi * self.radius ** 2

    def perimeter(self):
        return 2 * math.pi * self.radius
