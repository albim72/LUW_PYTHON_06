from geometry.shape import Shape


class Rectangle(Shape):
    def __init__(self, width, height):
        super().__init__("Prostokąt")
        self.width = width
        self.height = height

    @property
    def width(self):
        return self._width

    @width.setter
    def width(self, value):
        if value <= 0:
            raise ValueError("Szerokość musi być większa od zera.")
        self._width = value

    @property
    def height(self):
        return self._height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise ValueError("Wysokość musi być większa od zera.")
        self._height = value

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)
