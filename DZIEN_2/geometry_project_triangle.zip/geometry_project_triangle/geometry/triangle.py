import math

from geometry.shape import Shape


class Triangle(Shape):
    def __init__(self, side_a, side_b, side_c):
        super().__init__("Trójkąt")
        self.set_sides(side_a, side_b, side_c)

    @property
    def side_a(self):
        return self._side_a

    @property
    def side_b(self):
        return self._side_b

    @property
    def side_c(self):
        return self._side_c

    def set_sides(self, side_a, side_b, side_c):
        self._validate_sides(side_a, side_b, side_c)

        self._side_a = side_a
        self._side_b = side_b
        self._side_c = side_c

    def _validate_sides(self, side_a, side_b, side_c):
        if side_a <= 0 or side_b <= 0 or side_c <= 0:
            raise ValueError("Boki trójkąta muszą być większe od zera.")

        if side_a + side_b <= side_c:
            raise ValueError("Nie można zbudować trójkąta z podanych boków.")

        if side_a + side_c <= side_b:
            raise ValueError("Nie można zbudować trójkąta z podanych boków.")

        if side_b + side_c <= side_a:
            raise ValueError("Nie można zbudować trójkąta z podanych boków.")

    def perimeter(self):
        return self.side_a + self.side_b + self.side_c

    def area(self):
        half_perimeter = self.perimeter() / 2

        return math.sqrt(
            half_perimeter
            * (half_perimeter - self.side_a)
            * (half_perimeter - self.side_b)
            * (half_perimeter - self.side_c)
        )

    def show_info(self):
        super().show_info()
        print(f"Boki: {self.side_a}, {self.side_b}, {self.side_c}")
