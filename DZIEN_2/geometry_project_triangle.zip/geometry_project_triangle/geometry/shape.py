from abc import ABC, abstractmethod


class Shape(ABC):
    def __init__(self, name):
        self.name = name

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        if not value:
            raise ValueError("Nazwa figury nie może być pusta.")
        self._name = value

    @abstractmethod
    def area(self):
        pass

    @abstractmethod
    def perimeter(self):
        pass

    def show_info(self):
        print(f"Figura: {self.name}")
        print(f"Pole: {self.area()}")
        print(f"Obwód: {self.perimeter()}")
