from geometry.rectangle import Rectangle


class Square(Rectangle):
    def __init__(self, side):
        super().__init__(side, side)
        self.name = "Kwadrat"

    @property
    def side(self):
        return self.width

    @side.setter
    def side(self, value):
        self.width = value
        self.height = value
