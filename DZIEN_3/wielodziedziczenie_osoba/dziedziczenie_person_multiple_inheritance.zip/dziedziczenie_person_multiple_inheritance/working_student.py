"""
working_student.py

Moduł zawierający klasę WorkingStudent.

WorkingStudent jest najważniejszym przykładem wielodziedziczenia w projekcie.
Dziedziczy jednocześnie po klasie Employee oraz Student.

Oznacza to, że jedna klasa łączy cechy pracownika i studenta:
- dane osobowe z Person,
- dane pracownika z Employee,
- dane studenta z Student,
- własną informację o liczbie godzin pracy tygodniowo.
"""

from employee import Employee
from student import Student


class WorkingStudent(Employee, Student):
    """
    Klasa reprezentująca osobę, która jednocześnie pracuje i studiuje.

    To przykład klasycznego wielodziedziczenia. Klasa WorkingStudent łączy
    ścieżkę Employee oraz Student, a obie te klasy ostatecznie prowadzą do
    klasy Person.

    Python rozwiązuje taką strukturę przez MRO, czyli Method Resolution Order.
    """

    def __init__(
        self,
        first_name: str,
        last_name: str,
        age: int,
        position: str,
        salary: float,
        university: str,
        field_of_study: str,
        hours_per_week: int,
    ) -> None:
        """
        Konstruktor klasy WorkingStudent.

        Args:
            first_name: Imię osoby.
            last_name: Nazwisko osoby.
            age: Wiek osoby.
            position: Stanowisko pracy.
            salary: Pensja.
            university: Nazwa uczelni.
            field_of_study: Kierunek studiów.
            hours_per_week: Liczba godzin pracy tygodniowo.
        """
        # super() uruchamia łańcuch konstruktorów według MRO:
        # WorkingStudent -> Employee -> Student -> Person -> object.
        super().__init__(
            first_name=first_name,
            last_name=last_name,
            age=age,
            position=position,
            salary=salary,
            university=university,
            field_of_study=field_of_study,
        )

        self.hours_per_week = hours_per_week

    def show_info(self) -> None:
        """
        Wypisuje pełne informacje o pracującym studencie.

        Dzięki kooperacyjnemu super() metoda przechodzi przez klasy Employee,
        Student i Person, a na końcu dopisuje dane klasy WorkingStudent.
        """
        super().show_info()
        print(f"liczba godzin pracy tygodniowo: {self.hours_per_week}")

    def plan_week(self) -> None:
        """
        Wypisuje prosty komunikat o łączeniu pracy ze studiami.
        """
        print(
            f"{self.first_name} łączy pracę jako {self.position} "
            f"ze studiami na kierunku {self.field_of_study}."
        )
