# Dokumentacja projektu: Dziedziczenie i wielodziedziczenie w Pythonie

## 1. Cel projektu

Projekt pokazuje programowanie obiektowe w Pythonie na przykładzie klas opisujących osoby, pracowników, studentów oraz obiekty łączące kilka ról jednocześnie.

Pierwsza wersja projektu prezentowała klasyczne dziedziczenie:

```text
Person -> Employee
Person -> Student
```

Ta wersja została rozbudowana o wielodziedziczenie:

```text
Employee + Student -> WorkingStudent
ContactMixin + SkillsMixin + Employee + Student -> AcademicAssistant
```

Dzięki temu projekt pokazuje nie tylko proste relacje typu „pracownik jest osobą”, ale również bardziej realistyczne sytuacje, w których jeden obiekt może łączyć kilka zestawów cech.

Główne zagadnienia prezentowane w projekcie:

- klasy i obiekty,
- konstruktory `__init__`,
- atrybuty instancji,
- metody obiektowe,
- dziedziczenie pojedyncze,
- wielodziedziczenie,
- nadpisywanie metod,
- kooperacyjne użycie `super()`,
- przekazywanie argumentów przez `**kwargs`,
- MRO, czyli Method Resolution Order,
- mixiny jako małe klasy dodające konkretną funkcjonalność.

---

## 2. Struktura projektu

```text
dziedziczenie_person_multiple_inheritance/
├── main.py
├── person.py
├── employee.py
├── student.py
├── working_student.py
├── contact_mixin.py
├── skills_mixin.py
├── academic_assistant.py
└── DOKUMENTACJA.md
```

Opis plików:

| Plik | Rola w projekcie |
|---|---|
| `person.py` | Definiuje klasę bazową `Person`. |
| `employee.py` | Definiuje klasę `Employee`, która dziedziczy po `Person`. |
| `student.py` | Definiuje klasę `Student`, która dziedziczy po `Person`. |
| `working_student.py` | Definiuje klasę `WorkingStudent`, która dziedziczy po `Employee` i `Student`. |
| `contact_mixin.py` | Definiuje mixin `ContactMixin`, dodający e-mail i telefon. |
| `skills_mixin.py` | Definiuje mixin `SkillsMixin`, dodający listę umiejętności. |
| `academic_assistant.py` | Definiuje klasę `AcademicAssistant`, łączącą mixiny, pracownika i studenta. |
| `main.py` | Uruchamia aplikację i pokazuje działanie klas. |
| `DOKUMENTACJA.md` | Dokumentacja projektu. |

---

## 3. Schemat dziedziczenia pojedynczego

```text
        Person
       /      \
 Employee    Student
```

Klasa `Person` jest klasą bazową. Zawiera dane wspólne dla każdej osoby:

- imię,
- nazwisko,
- wiek.

Klasy `Employee` i `Student` są klasami potomnymi. Dziedziczą po `Person`, ale dodają własne pola i metody.

---

## 4. Schemat wielodziedziczenia: `WorkingStudent`

```text
        Person
       /      \
 Employee    Student
       \      /
    WorkingStudent
```

Klasa `WorkingStudent` dziedziczy po dwóch klasach:

```python
class WorkingStudent(Employee, Student):
    ...
```

Oznacza to, że obiekt klasy `WorkingStudent` posiada cechy pracownika i studenta jednocześnie.

Przykład:

```python
working_student = WorkingStudent(
    first_name="Maria",
    last_name="Zielińska",
    age=24,
    position="Junior Python Developer",
    salary=6200,
    university="Politechnika Warszawska",
    field_of_study="Informatyka",
    hours_per_week=20,
)
```

Taki obiekt może wywoływać metody klasy `Employee`:

```python
working_student.work()
```

oraz metody klasy `Student`:

```python
working_student.zaliczenie_semestru(88)
```

---

## 5. MRO, czyli Method Resolution Order

MRO to kolejność, w jakiej Python szuka metod i konstruktorów w klasach bazowych.

Dla klasy `WorkingStudent` kolejność wygląda następująco:

```text
WorkingStudent -> Employee -> Student -> Person -> object
```

Można to sprawdzić w kodzie:

```python
print(WorkingStudent.mro())
```

W projekcie służy do tego funkcja pomocnicza:

```python
def print_mro(class_type: type) -> None:
    names = [single_class.__name__ for single_class in class_type.mro()]
    print("MRO:", " -> ".join(names))
```

MRO jest bardzo ważne przy wielodziedziczeniu. Bez niego Python nie wiedziałby, czy najpierw ma szukać metody w klasie `Employee`, czy w klasie `Student`.

---

## 6. Dlaczego używamy `super()` i `**kwargs`?

W prostym dziedziczeniu często wystarcza zapis:

```python
super().__init__(first_name, last_name, age)
```

Przy wielodziedziczeniu to może być za mało. Każda klasa potrzebuje własnych argumentów:

- `Person` potrzebuje `first_name`, `last_name`, `age`,
- `Employee` potrzebuje `position`, `salary`,
- `Student` potrzebuje `university`, `field_of_study`,
- `ContactMixin` potrzebuje `email`, `phone`,
- `SkillsMixin` potrzebuje `skills`.

Dlatego konstruktory przyjmują `**kwargs` i przekazują dalej argumenty, których same nie zużywają.

Przykład z klasy `Employee`:

```python
super().__init__(first_name=first_name, last_name=last_name, age=age, **kwargs)
self.position = position
self.salary = salary
```

Klasa `Employee` bierze dla siebie `position` i `salary`, a resztę przekazuje dalej.

To nazywa się kooperacyjnym dziedziczeniem. Każda klasa bierze swój kawałek danych i nie blokuje pozostałych klas.

---

## 7. Moduł `person.py`

Moduł `person.py` zawiera klasę `Person`.

### Klasa `Person`

Atrybuty:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `first_name` | `str` | Imię osoby. |
| `last_name` | `str` | Nazwisko osoby. |
| `age` | `int` | Wiek osoby. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `__init__()` | Konstruktor tworzący obiekt osoby. |
| `__repr__()` | Zwraca tekstowy opis osoby. |
| `show_info()` | Wypisuje imię, nazwisko i wiek. |
| `introduce()` | Wypisuje krótkie przedstawienie osoby. |
| `wiek_za_n_lat(n)` | Zwraca wiek osoby za `n` lat. |

W tej wersji projektu konstruktor klasy `Person` wygląda tak:

```python
def __init__(self, first_name: str, last_name: str, age: int, **kwargs) -> None:
    super().__init__(**kwargs)
    self.first_name = first_name
    self.last_name = last_name
    self.age = age
```

To pozwala klasie `Person` współpracować z wielodziedziczeniem.

---

## 8. Moduł `employee.py`

Moduł `employee.py` zawiera klasę `Employee`.

### Klasa `Employee`

Klasa `Employee` dziedziczy po klasie `Person`.

Dodatkowe atrybuty:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `position` | `str` | Stanowisko pracownika. |
| `salary` | `float` | Pensja pracownika. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `__init__()` | Tworzy pracownika. |
| `__str__()` | Zwraca opis pracownika. |
| `show_info()` | Rozszerza informacje o stanowisko i pensję. |
| `work()` | Wypisuje informację o pracy. |
| `raise_work(percent)` | Oblicza pensję po podwyżce procentowej. |

---

## 9. Moduł `student.py`

Moduł `student.py` zawiera klasę `Student`.

### Klasa `Student`

Klasa `Student` dziedziczy po klasie `Person`.

Dodatkowe atrybuty:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `university` | `str` | Nazwa uczelni. |
| `field_of_study` | `str` | Kierunek studiów. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `__init__()` | Tworzy studenta. |
| `show_info()` | Rozszerza informacje o uczelnię i kierunek. |
| `zaliczenie_semestru(punkty)` | Sprawdza zaliczenie semestru. |

---

## 10. Moduł `working_student.py`

Moduł `working_student.py` zawiera klasę `WorkingStudent`.

### Klasa `WorkingStudent`

Klasa `WorkingStudent` dziedziczy po dwóch klasach:

```python
class WorkingStudent(Employee, Student):
    ...
```

Dzięki temu ma dostęp do danych i metod pracownika oraz studenta.

Dodatkowy atrybut:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `hours_per_week` | `int` | Liczba godzin pracy tygodniowo. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `show_info()` | Wypisuje informacje osoby, studenta, pracownika i pracującego studenta. |
| `plan_week()` | Wypisuje komunikat o łączeniu pracy ze studiami. |

Ważny fragment:

```python
super().__init__(
    first_name=first_name,
    last_name=last_name,
    age=age,
    position=position,
    salary=salary,
    university=university,
    field_of_study=field_of_study,
)
```

To wywołanie uruchamia cały łańcuch konstruktorów według MRO.

---

## 11. Moduł `contact_mixin.py`

Moduł `contact_mixin.py` zawiera klasę `ContactMixin`.

Mixin to mała klasa pomocnicza, która dodaje jedną konkretną funkcjonalność.

### Klasa `ContactMixin`

Atrybuty:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `email` | `str` | Adres e-mail. |
| `phone` | `str` | Numer telefonu. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `show_info()` | Rozszerza opis o dane kontaktowe. |
| `send_email(message)` | Symuluje wysłanie wiadomości e-mail. |

Mixin nie reprezentuje samodzielnej osoby. Dodaje tylko funkcjonalność kontaktową.

---

## 12. Moduł `skills_mixin.py`

Moduł `skills_mixin.py` zawiera klasę `SkillsMixin`.

### Klasa `SkillsMixin`

Atrybuty:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `skills` | `list[str]` | Lista umiejętności. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `show_info()` | Rozszerza opis o listę umiejętności. |
| `add_skill(skill)` | Dodaje nową umiejętność. |
| `show_skills()` | Wypisuje listę umiejętności. |

Ważny fragment:

```python
self.skills = skills if skills is not None else []
```

Nie używamy domyślnej wartości `skills=[]`, ponieważ lista jako domyślny argument funkcji mogłaby być współdzielona między różnymi obiektami.

---

## 13. Moduł `academic_assistant.py`

Moduł `academic_assistant.py` zawiera klasę `AcademicAssistant`.

### Klasa `AcademicAssistant`

Klasa `AcademicAssistant` dziedziczy po czterech klasach:

```python
class AcademicAssistant(ContactMixin, SkillsMixin, Employee, Student):
    ...
```

Oznacza to, że łączy kilka warstw funkcjonalności:

| Klasa bazowa | Co wnosi? |
|---|---|
| `ContactMixin` | E-mail, telefon, metoda `send_email()`. |
| `SkillsMixin` | Umiejętności, `add_skill()`, `show_skills()`. |
| `Employee` | Stanowisko, pensja, metoda `work()`. |
| `Student` | Uczelnia, kierunek, metoda `zaliczenie_semestru()`. |
| `Person` | Imię, nazwisko, wiek, `introduce()`. |

Dodatkowy atrybut:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `research_area` | `str` | Obszar badawczy. |

Dla tej klasy MRO wygląda tak:

```text
AcademicAssistant -> ContactMixin -> SkillsMixin -> Employee -> Student -> Person -> object
```

To oznacza, że metoda `show_info()` przechodzi przez kilka klas i każda dodaje własną część informacji.

---

## 14. Moduł `main.py`

Moduł `main.py` jest głównym punktem startowym aplikacji.

Wykonuje następujące kroki:

1. Importuje wszystkie klasy.
2. Tworzy obiekt `Person`.
3. Tworzy obiekt `Employee`.
4. Tworzy obiekt `Student`.
5. Tworzy obiekt `WorkingStudent`.
6. Tworzy obiekt `AcademicAssistant`.
7. Wywołuje metody pokazujące dziedziczenie i wielodziedziczenie.
8. Wypisuje MRO dla klas wielodziedziczących.

Fragment startowy:

```python
if __name__ == "__main__":
    main()
```

Ten zapis oznacza, że funkcja `main()` zostanie uruchomiona tylko wtedy, gdy plik `main.py` zostanie uruchomiony bezpośrednio.

---

## 15. Jak uruchomić projekt

W terminalu przejdź do katalogu projektu:

```bash
cd dziedziczenie_person_multiple_inheritance
```

Następnie uruchom:

```bash
python main.py
```

Jeżeli w systemie komenda `python` wskazuje na starszą wersję Pythona, użyj:

```bash
python3 main.py
```

---

## 16. Co powinno pojawić się w konsoli?

Program wypisze sekcje:

```text
OSOBA
PRACOWNIK
STUDENT
PRACUJĄCY STUDENT - WIELODZIEDZICZENIE
ASYSTENT AKADEMICKI - MIXINY I WIELODZIEDZICZENIE
```

W sekcjach z wielodziedziczeniem pojawi się także MRO, na przykład:

```text
MRO: WorkingStudent -> Employee -> Student -> Person -> object
```

oraz:

```text
MRO: AcademicAssistant -> ContactMixin -> SkillsMixin -> Employee -> Student -> Person -> object
```

---

## 17. Najważniejszy morał dydaktyczny

Wielodziedziczenie w Pythonie ma sens wtedy, gdy klasy współpracują przez `super()` i przekazują dalej argumenty przez `**kwargs`.

Nie chodzi tylko o to, żeby napisać:

```python
class X(A, B):
    pass
```

Prawdziwa lekcja zaczyna się wtedy, gdy kilka klas potrafi razem zbudować jeden obiekt, każda dopisując własną warstwę odpowiedzialności. Wtedy hierarchia nie jest drabiną. Jest siecią. A Python, przez MRO, pilnuje kolejności przejścia przez tę sieć.
