"""
person.py

Moduł bazowy projektu.

Zawiera klasę Person, która reprezentuje ogólną osobę.
Jest to klasa nadrzędna dla bardziej szczegółowych klas, takich jak Employee,
Student oraz WorkingStudent.

W tej wersji projektu klasa Person została przygotowana również pod
wielodziedziczenie. Konstruktor przyjmuje **kwargs i wywołuje super().__init__().
Dzięki temu może współpracować z innymi klasami w łańcuchu MRO, czyli Method
Resolution Order.
"""


class Person:
    """
    Klasa reprezentująca podstawową osobę.

    Przechowuje dane wspólne dla każdej osoby:
    - imię,
    - nazwisko,
    - wiek.

    Klasa Person pełni w projekcie rolę klasy bazowej. Inne klasy dziedziczą po
    niej i rozszerzają jej funkcjonalność o własne pola oraz metody.
    """

    def __init__(self, first_name: str, last_name: str, age: int, **kwargs) -> None:
        """
        Konstruktor klasy Person.

        Parametr **kwargs jest tutaj bardzo ważny przy wielodziedziczeniu.
        Pozwala przekazywać dalej dodatkowe argumenty, których Person nie używa,
        ale które mogą być potrzebne innym klasom w łańcuchu dziedziczenia.

        Args:
            first_name: Imię osoby.
            last_name: Nazwisko osoby.
            age: Wiek osoby wyrażony jako liczba całkowita.
            **kwargs: Dodatkowe argumenty przekazywane dalej przez super().
        """
        # super().__init__(**kwargs) kończy łańcuch cooperative inheritance.
        # Gdy kwargs jest puste, wywoływany jest object.__init__().
        super().__init__(**kwargs)

        # Atrybuty instancji, czyli dane przypisane do konkretnego obiektu.
        self.first_name = first_name
        self.last_name = last_name
        self.age = age

    def __repr__(self) -> str:
        """
        Zwraca tekstową reprezentację obiektu.

        Returns:
            Tekst z imieniem, nazwiskiem i wiekiem osoby.
        """
        return f"{self.first_name} {self.last_name} -> {self.age} lat/a"

    def show_info(self) -> None:
        """
        Wypisuje podstawowe informacje o osobie.

        Ta metoda jest również częścią łańcucha metod wywoływanych przez super()
        w klasach potomnych. Przy wielodziedziczeniu kolejne klasy mogą ją
        rozszerzać, a nie całkowicie zastępować.
        """
        print(f"imię: {self.first_name}")
        print(f"nazwisko: {self.last_name}")
        print(f"wiek: {self.age}")

    def introduce(self) -> None:
        """
        Wypisuje krótkie przedstawienie osoby.
        """
        print(f"Nazywam się: {self.first_name} {self.last_name}")

    def wiek_za_n_lat(self, n: int) -> int:
        """
        Oblicza wiek osoby za podaną liczbę lat.

        Args:
            n: Liczba lat, którą chcemy dodać do aktualnego wieku.

        Returns:
            Wiek osoby po dodaniu podanej liczby lat.
        """
        return self.age + n
