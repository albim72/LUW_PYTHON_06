"""
student.py

Moduł zawierający klasę Student.

Klasa Student dziedziczy po klasie Person. Dzięki temu student automatycznie
posiada imię, nazwisko, wiek oraz metody zdefiniowane w klasie bazowej.
W tej wersji projektu konstruktor klasy Student obsługuje także
wielodziedziczenie przez mechanizm super() oraz **kwargs.
"""

from person import Person


class Student(Person):
    """
    Klasa reprezentująca studenta.

    Student jest szczególnym przypadkiem osoby. Oprócz danych podstawowych
    posiada nazwę uczelni oraz kierunek studiów.
    """

    def __init__(
        self,
        first_name: str,
        last_name: str,
        age: int,
        university: str,
        field_of_study: str,
        **kwargs,
    ) -> None:
        """
        Konstruktor klasy Student.

        Podobnie jak w klasie Employee, używamy super(), aby nie powielać kodu.
        Przy wielodziedziczeniu super() nie musi oznaczać bezpośrednio klasy
        Person. Oznacza następną klasę w kolejności MRO.

        Args:
            first_name: Imię studenta.
            last_name: Nazwisko studenta.
            age: Wiek studenta.
            university: Nazwa uczelni.
            field_of_study: Kierunek studiów.
            **kwargs: Dodatkowe argumenty dla kolejnych klas w MRO.
        """
        # Wywołanie kolejnego konstruktora według MRO.
        super().__init__(first_name=first_name, last_name=last_name, age=age, **kwargs)

        # Atrybuty specyficzne dla studenta.
        self.university = university
        self.field_of_study = field_of_study

    def show_info(self) -> None:
        """
        Wypisuje informacje o studencie.

        Metoda jest kooperacyjna. Dzięki temu może współpracować z metodą
        show_info z klasy Employee w klasie WorkingStudent.
        """
        super().show_info()
        print(f"uczelnia: {self.university}")
        print(f"kierunek studiów: {self.field_of_study}")

    def zaliczenie_semestru(self, punkty: int) -> None:
        """
        Sprawdza, czy student zaliczył semestr.

        Args:
            punkty: Liczba punktów zdobytych przez studenta.
        """
        prog_zaliczenia = 70

        print(f"próg zaliczenia -> {prog_zaliczenia}")

        if punkty >= prog_zaliczenia:
            print(f"zaliczenie semestru -> liczba punktów {punkty}")
        else:
            print(f"brak zaliczenia semestru -> liczba punktów {punkty}")
