"""
academic_assistant.py

Moduł zawierający klasę AcademicAssistant.

AcademicAssistant pokazuje bardziej rozbudowane wielodziedziczenie. Klasa łączy:
- ContactMixin, czyli dane kontaktowe,
- SkillsMixin, czyli listę umiejętności,
- Employee, czyli dane pracownika,
- Student, czyli dane studenta.

To już nie jest zwykły przykład z podręcznika. To mała orkiestra MRO, gdzie
każda klasa gra swój instrument i nie wchodzi innym w melodię.
"""

from contact_mixin import ContactMixin
from employee import Employee
from skills_mixin import SkillsMixin
from student import Student


class AcademicAssistant(ContactMixin, SkillsMixin, Employee, Student):
    """
    Klasa reprezentująca asystenta akademickiego.

    Asystent akademicki może jednocześnie:
    - być studentem,
    - być pracownikiem,
    - mieć dane kontaktowe,
    - mieć listę umiejętności.

    Kolejność dziedziczenia ma znaczenie, ponieważ wpływa na MRO.
    """

    def __init__(
        self,
        first_name: str,
        last_name: str,
        age: int,
        email: str,
        phone: str,
        skills: list[str],
        position: str,
        salary: float,
        university: str,
        field_of_study: str,
        research_area: str,
    ) -> None:
        """
        Konstruktor klasy AcademicAssistant.

        Args:
            first_name: Imię osoby.
            last_name: Nazwisko osoby.
            age: Wiek osoby.
            email: Adres e-mail.
            phone: Numer telefonu.
            skills: Lista umiejętności.
            position: Stanowisko pracy.
            salary: Pensja.
            university: Nazwa uczelni.
            field_of_study: Kierunek studiów.
            research_area: Obszar badawczy.
        """
        # Łańcuch MRO dla tej klasy:
        # AcademicAssistant -> ContactMixin -> SkillsMixin -> Employee ->
        # Student -> Person -> object.
        super().__init__(
            first_name=first_name,
            last_name=last_name,
            age=age,
            email=email,
            phone=phone,
            skills=skills,
            position=position,
            salary=salary,
            university=university,
            field_of_study=field_of_study,
        )

        self.research_area = research_area

    def show_info(self) -> None:
        """
        Wypisuje pełne informacje o asystencie akademickim.
        """
        super().show_info()
        print(f"obszar badawczy: {self.research_area}")

    def conduct_lab(self, topic: str) -> None:
        """
        Symuluje prowadzenie zajęć laboratoryjnych.

        Args:
            topic: Temat laboratorium.
        """
        print(f"{self.first_name} prowadzi laboratorium z tematu: {topic}")
