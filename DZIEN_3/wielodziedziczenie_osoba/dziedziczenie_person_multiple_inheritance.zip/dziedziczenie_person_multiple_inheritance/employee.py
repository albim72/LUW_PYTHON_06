"""
employee.py

Moduł zawierający klasę Employee.

Klasa Employee dziedziczy po klasie Person i rozszerza ją o dane pracownika:
stanowisko oraz pensję. Konstruktor klasy został przygotowany tak, aby działał
również w układzie wielodziedziczenia, na przykład w klasie WorkingStudent.
"""

from person import Person


class Employee(Person):
    """
    Klasa reprezentująca pracownika.

    Employee jest szczególnym rodzajem osoby. Ma imię, nazwisko i wiek, ale
    dodatkowo posiada stanowisko oraz pensję.
    """

    def __init__(
        self,
        first_name: str,
        last_name: str,
        age: int,
        position: str,
        salary: float,
        **kwargs,
    ) -> None:
        """
        Konstruktor klasy Employee.

        W zwykłym dziedziczeniu super() wywołałoby bezpośrednio Person.
        W wielodziedziczeniu super() wywołuje następną klasę zgodnie z MRO,
        czyli Method Resolution Order. Dlatego pozostałe argumenty przekazujemy
        dalej przez **kwargs.

        Args:
            first_name: Imię pracownika.
            last_name: Nazwisko pracownika.
            age: Wiek pracownika.
            position: Stanowisko pracownika.
            salary: Pensja pracownika.
            **kwargs: Dodatkowe argumenty dla kolejnych klas w MRO.
        """
        # W klasie Employee pobieramy tylko dane pracownika, a dane osoby oraz
        # ewentualne dane innych klas przekazujemy dalej.
        super().__init__(first_name=first_name, last_name=last_name, age=age, **kwargs)

        # Atrybuty specyficzne dla klasy Employee.
        self.position = position
        self.salary = salary

    def __str__(self) -> str:
        """
        Zwraca czytelny opis pracownika.

        Returns:
            Tekst zawierający dane osobowe, stanowisko i pensję.
        """
        return (
            f"{self.first_name} {self.last_name} -> "
            f"{self.age} lat/a -> {self.position} -> {self.salary}"
        )

    def show_info(self) -> None:
        """
        Wypisuje informacje o pracowniku.

        Metoda działa kooperacyjnie. Najpierw wywołuje super().show_info(),
        czyli następną metodę show_info według MRO, a potem dopisuje informacje
        właściwe dla pracownika.
        """
        super().show_info()
        print(f"stanowisko: {self.position}")
        print(f"pensja: {self.salary} zł")

    def work(self) -> None:
        """
        Wypisuje informację o pracy wykonywanej przez pracownika.
        """
        print(
            f"pracownik {self.first_name} {self.last_name} "
            f"pracuje na stanowisku {self.position}"
        )

    def raise_work(self, percent: float) -> float:
        """
        Oblicza pensję po podwyżce procentowej.

        Metoda nie zmienia trwale wartości self.salary. Zwraca tylko wynik
        obliczenia, czyli pensję powiększoną o wskazany procent.

        Args:
            percent: Procent podwyżki, na przykład 15 oznacza 15%.

        Returns:
            Nowa pensja po doliczeniu podwyżki.
        """
        return self.salary + percent * self.salary / 100
