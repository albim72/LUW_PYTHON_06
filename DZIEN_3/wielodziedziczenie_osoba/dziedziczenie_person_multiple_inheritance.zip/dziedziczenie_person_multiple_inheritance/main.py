"""
main.py

Główny moduł aplikacji.

Ten plik uruchamia cały projekt demonstracyjny. Pokazuje działanie:
- zwykłego dziedziczenia,
- nadpisywania metod,
- użycia super(),
- wielodziedziczenia,
- MRO, czyli Method Resolution Order,
- mixinów, czyli małych klas dodających konkretną funkcjonalność.

Aplikacja tworzy kilka obiektów i wywołuje ich metody. Dzięki temu można
zobaczyć, które zachowania są wspólne, które zostały dodane w klasach potomnych,
a które powstają przez połączenie kilku klas bazowych.
"""

from academic_assistant import AcademicAssistant
from employee import Employee
from person import Person
from student import Student
from working_student import WorkingStudent


def print_section(title: str) -> None:
    """
    Wypisuje czytelny nagłówek sekcji.

    Args:
        title: Tytuł sekcji wypisywany w konsoli.
    """
    print("\n" + "=" * 12 + f" {title} " + "=" * 12)


def print_mro(class_type: type) -> None:
    """
    Wypisuje kolejność rozwiązywania metod dla danej klasy.

    MRO, czyli Method Resolution Order, mówi Pythonowi, w jakiej kolejności ma
    szukać metod i konstruktorów w hierarchii dziedziczenia.

    Args:
        class_type: Klasa, dla której chcemy pokazać MRO.
    """
    names = [single_class.__name__ for single_class in class_type.mro()]
    print("MRO:", " -> ".join(names))


def main() -> None:
    """
    Funkcja główna programu.

    Odpowiada za:
    1. Utworzenie przykładowych obiektów.
    2. Pokazanie zwykłego dziedziczenia: Person -> Employee / Student.
    3. Pokazanie wielodziedziczenia: Employee + Student -> WorkingStudent.
    4. Pokazanie mixinów: ContactMixin + SkillsMixin + Employee + Student.
    5. Demonstrację MRO.

    Funkcja nie zwraca wartości. Wszystkie wyniki są wypisywane w konsoli.
    """
    # Tworzymy obiekt klasy bazowej Person.
    person = Person("Jan", "Kowalski", 48)

    # Tworzymy obiekt klasy Employee, która dziedziczy po Person.
    employee = Employee("Anna", "Nowak", 35, "Asystentka prezesa", 8700)

    # Tworzymy obiekt klasy Student, która również dziedziczy po Person.
    student = Student("Olaf", "Jankowski", 22, "SWPS", "Sztuczna inteligencja")

    # WorkingStudent dziedziczy jednocześnie po Employee i Student.
    working_student = WorkingStudent(
        first_name="Maria",
        last_name="Zielińska",
        age=24,
        position="Junior Python Developer",
        salary=6200,
        university="Politechnika Warszawska",
        field_of_study="Informatyka",
        hours_per_week=20,
    )

    # AcademicAssistant używa jeszcze bardziej rozbudowanego wielodziedziczenia:
    # ContactMixin + SkillsMixin + Employee + Student.
    academic_assistant = AcademicAssistant(
        first_name="Piotr",
        last_name="Wiśniewski",
        age=27,
        email="piotr.wisniewski@example.com",
        phone="+48 600 700 800",
        skills=["Python", "analiza danych", "machine learning"],
        position="Asystent akademicki",
        salary=7200,
        university="SWPS",
        field_of_study="Sztuczna inteligencja",
        research_area="systemy rekomendacyjne",
    )

    print_section("OSOBA")
    print(person)
    person.show_info()
    person.introduce()
    print(f"wiek za 5 lat: {person.wiek_za_n_lat(5)} lat/a")

    print_section("PRACOWNIK")
    employee.show_info()
    employee.introduce()
    employee.work()
    print(f"pensja po podwyżce: {employee.raise_work(15)} zł")

    print_section("STUDENT")
    student.show_info()
    student.introduce()
    student.zaliczenie_semestru(78)

    print_section("PRACUJĄCY STUDENT - WIELODZIEDZICZENIE")
    working_student.show_info()
    working_student.work()
    working_student.zaliczenie_semestru(88)
    working_student.plan_week()
    print_mro(WorkingStudent)

    print_section("ASYSTENT AKADEMICKI - MIXINY I WIELODZIEDZICZENIE")
    academic_assistant.show_info()
    academic_assistant.work()
    academic_assistant.zaliczenie_semestru(91)
    academic_assistant.add_skill("prowadzenie laboratoriów")
    academic_assistant.show_skills()
    academic_assistant.send_email("Przypomnienie o terminie laboratorium.")
    academic_assistant.conduct_lab("wielodziedziczenie w Pythonie")
    print_mro(AcademicAssistant)


# Ten warunek sprawia, że main() uruchomi się tylko wtedy, gdy plik main.py
# zostanie uruchomiony bezpośrednio. Jeśli plik zostanie zaimportowany jako moduł,
# kod wewnątrz tego bloku nie wykona się automatycznie.
if __name__ == "__main__":
    main()
