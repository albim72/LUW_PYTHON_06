"""
skills_mixin.py

Moduł zawierający klasę SkillsMixin.

SkillsMixin dodaje do obiektu listę umiejętności. Dzięki temu tę samą
funkcjonalność można wykorzystać w różnych klasach, bez tworzenia dużej,
monolitycznej hierarchii dziedziczenia.
"""


class SkillsMixin:
    """
    Mixin dodający obsługę umiejętności.

    Przykład umiejętności:
    - Python,
    - analiza danych,
    - komunikacja,
    - machine learning.
    """

    def __init__(self, skills: list[str] | None = None, **kwargs) -> None:
        """
        Konstruktor klasy SkillsMixin.

        Args:
            skills: Lista początkowych umiejętności. Jeśli nie zostanie podana,
                tworzona jest pusta lista.
            **kwargs: Dodatkowe argumenty przekazywane dalej przez super().
        """
        super().__init__(**kwargs)

        # Nie używamy domyślnej wartości skills=[], ponieważ lista jako wartość
        # domyślna byłaby współdzielona między obiektami. To klasyczna pułapka
        # Pythona, mały smok ukryty pod dywanem składni.
        self.skills = skills if skills is not None else []

    def show_info(self) -> None:
        """
        Rozszerza metodę show_info o listę umiejętności.
        """
        super().show_info()
        print(f"umiejętności: {', '.join(self.skills) if self.skills else 'brak'}")

    def add_skill(self, skill: str) -> None:
        """
        Dodaje nową umiejętność do listy.

        Args:
            skill: Nazwa umiejętności do dodania.
        """
        self.skills.append(skill)

    def show_skills(self) -> None:
        """
        Wypisuje wszystkie umiejętności obiektu.
        """
        if not self.skills:
            print("Brak zapisanych umiejętności.")
            return

        print("Lista umiejętności:")
        for index, skill in enumerate(self.skills, start=1):
            print(f"{index}. {skill}")
