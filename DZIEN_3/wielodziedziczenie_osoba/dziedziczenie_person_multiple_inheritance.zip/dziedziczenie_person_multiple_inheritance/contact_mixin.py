"""
contact_mixin.py

Moduł zawierający klasę ContactMixin.

Mixin to mała klasa pomocnicza, której zadaniem jest dodanie jednej konkretnej
funkcjonalności do innych klas. ContactMixin dodaje dane kontaktowe: e-mail oraz
telefon.

Mixin zwykle nie opisuje pełnego bytu, takiego jak osoba, pracownik czy student.
Opisuje raczej cechę albo zestaw zachowań, które można dołączyć do różnych klas.
"""


class ContactMixin:
    """
    Mixin dodający dane kontaktowe.

    Ta klasa pokazuje praktyczny sens wielodziedziczenia. Możemy połączyć ją z
    innymi klasami, na przykład z Employee i Student, bez przepisywania kodu
    obsługi kontaktu.
    """

    def __init__(self, email: str, phone: str, **kwargs) -> None:
        """
        Konstruktor klasy ContactMixin.

        Args:
            email: Adres e-mail.
            phone: Numer telefonu.
            **kwargs: Dodatkowe argumenty przekazywane dalej w łańcuchu MRO.
        """
        # Najpierw przekazujemy pozostałe argumenty dalej. Dzięki temu każda
        # klasa w MRO dostanie te dane, które są jej potrzebne.
        super().__init__(**kwargs)

        self.email = email
        self.phone = phone

    def show_info(self) -> None:
        """
        Rozszerza metodę show_info o dane kontaktowe.

        Najpierw wywołujemy super().show_info(), aby wcześniejsze klasy mogły
        wypisać swoje informacje. Potem dokładamy dane kontaktowe.
        """
        super().show_info()
        print(f"e-mail: {self.email}")
        print(f"telefon: {self.phone}")

    def send_email(self, message: str) -> None:
        """
        Symuluje wysłanie wiadomości e-mail.

        Args:
            message: Treść wiadomości.
        """
        print(f"Wysyłam wiadomość do {self.email}: {message}")
