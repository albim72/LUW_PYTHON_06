class Vehicle:
    """
    Klasa reprezentująca pojazd.

    Przechowuje podstawowe informacje o pojeździe:
    - markę,
    - rok produkcji.
    """

    def __init__(self, brand, year):
        """
        Konstruktor klasy Vehicle.

        Parametry:
        brand - marka pojazdu
        year  - rok produkcji pojazdu
        """
        self.brand = brand
        self.year = year
