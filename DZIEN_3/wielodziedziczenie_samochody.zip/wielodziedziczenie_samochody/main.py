from car import Car


# Tworzymy obiekt klasy Car.
# Klasa Car dziedziczy po Vehicle oraz Engine.
car = Car("Toyota", 2020, 2.0, 150)

# Wywołujemy metodę, która wypisuje dane samochodu.
car.show_info()

# Dodatkowo możemy sprawdzić MRO, czyli kolejność szukania metod.
print()
print("MRO klasy Car:")
print(Car.mro())
