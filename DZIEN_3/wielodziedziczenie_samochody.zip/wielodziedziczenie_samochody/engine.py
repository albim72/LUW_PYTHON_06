class Engine:
    """
    Klasa reprezentująca silnik.

    Przechowuje podstawowe informacje o silniku:
    - pojemność,
    - moc.
    """

    def __init__(self, capacity, power):
        """
        Konstruktor klasy Engine.

        Parametry:
        capacity - pojemność silnika, np. 2.0
        power    - moc silnika w koniach mechanicznych
        """
        self.capacity = capacity
        self.power = power
