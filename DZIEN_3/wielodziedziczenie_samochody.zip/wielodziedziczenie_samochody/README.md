# Wielodziedziczenie w Pythonie — samochody

To jest bardzo prosty projekt pokazujący wielodziedziczenie w Pythonie.

## Struktura projektu

Projekt składa się z kilku plików:

- `vehicle.py` — zawiera klasę `Vehicle`
- `engine.py` — zawiera klasę `Engine`
- `car.py` — zawiera klasę `Car`, która dziedziczy po `Vehicle` i `Engine`
- `main.py` — uruchamia przykład

## Schemat dziedziczenia

```text
Vehicle      Engine
   \         /
    \       /
      Car
```

Klasa `Car` dziedziczy po dwóch klasach jednocześnie:

```python
class Car(Vehicle, Engine):
```

Oznacza to, że samochód ma cechy pojazdu oraz cechy silnika.

## Jak uruchomić projekt?

W terminalu przejdź do katalogu projektu i wpisz:

```bash
python main.py
```

## Przykładowy wynik

```text
Marka: Toyota
Rok produkcji: 2020
Pojemność silnika: 2.0 l
Moc silnika: 150 KM

MRO klasy Car:
[<class 'car.Car'>, <class 'vehicle.Vehicle'>, <class 'engine.Engine'>, <class 'object'>]
```

## Cel dydaktyczny

Celem projektu jest pokazanie, że jedna klasa w Pythonie może dziedziczyć po więcej niż jednej klasie.

W tym przykładzie:

- `Vehicle` przechowuje dane pojazdu,
- `Engine` przechowuje dane silnika,
- `Car` łączy obie te klasy.
