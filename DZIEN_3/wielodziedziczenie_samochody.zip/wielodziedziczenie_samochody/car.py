from vehicle import Vehicle
from engine import Engine


class Car(Vehicle, Engine):
    """
    Klasa reprezentująca samochód.

    Klasa Car korzysta z wielodziedziczenia,
    ponieważ dziedziczy jednocześnie po dwóch klasach:
    - Vehicle
    - Engine
    """

    def __init__(self, brand, year, capacity, power):
        """
        Konstruktor klasy Car.

        Parametry:
        brand    - marka samochodu
        year     - rok produkcji
        capacity - pojemność silnika
        power    - moc silnika

        W tym prostym przykładzie jawnie wywołujemy konstruktory
        obu klas bazowych.
        """
        Vehicle.__init__(self, brand, year)
        Engine.__init__(self, capacity, power)

    def show_info(self):
        """
        Metoda wypisująca informacje o samochodzie.
        """
        print(f"Marka: {self.brand}")
        print(f"Rok produkcji: {self.year}")
        print(f"Pojemność silnika: {self.capacity} l")
        print(f"Moc silnika: {self.power} KM")
