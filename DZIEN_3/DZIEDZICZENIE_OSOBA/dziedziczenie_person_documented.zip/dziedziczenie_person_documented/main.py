"""
main.py

Główny moduł aplikacji.

Ten plik uruchamia cały projekt demonstracyjny. Pokazuje działanie dziedziczenia
w Pythonie na przykładzie trzech klas:
- Person,
- Employee,
- Student.

Aplikacja tworzy po jednym obiekcie każdej klasy i wywołuje ich metody. Dzięki
temu można zobaczyć, które zachowania są wspólne, a które zostały dodane albo
nadpisane w klasach potomnych.
"""

from person import Person
from employee import Employee
from student import Student


def main() -> None:
    """
    Funkcja główna programu.

    Odpowiada za:
    1. Utworzenie przykładowych obiektów.
    2. Wywołanie metod pokazujących informacje o osobie, pracowniku i studencie.
    3. Demonstrację dziedziczenia, nadpisywania metod oraz użycia super().

    Funkcja nie zwraca wartości. Wszystkie wyniki są wypisywane w konsoli.
    """
    # Tworzymy obiekt klasy bazowej Person.
    person = Person("Jan", "Kowalski", 48)

    # Tworzymy obiekt klasy Employee, która dziedziczy po Person.
    employee = Employee("Anna", "Nowak", 35, "Asystentka prezesa", 8700)

    # Tworzymy obiekt klasy Student, która również dziedziczy po Person.
    student = Student("Olaf", "Jankowski", 22, "SWPS", "Sztuczna inteligencja")

    print("_________ OSOBA __________")

    # print(person) uruchamia metodę __repr__ z klasy Person.
    print(person)

    # Metody klasy Person.
    person.show_info()
    person.introduce()
    print(f"wiek za 5 lat: {person.wiek_za_n_lat(5)} lat/a")

    print("_________ PRACOWNIK __________")

    # Employee korzysta z metody show_info nadpisanej w klasie potomnej.
    employee.show_info()

    # introduce() nie jest zdefiniowane w Employee, więc zostaje odziedziczone z Person.
    employee.introduce()

    # Metody dostępne tylko dla pracownika.
    employee.work()
    print(f"pensja po podwyżce: {employee.raise_work(15)} zł")

    print("_________ STUDENT __________")

    # Student także nadpisuje show_info, aby dodać uczelnię i kierunek studiów.
    student.show_info()

    # introduce() pochodzi z klasy bazowej Person.
    student.introduce()

    # Metoda specyficzna dla klasy Student.
    student.zaliczenie_semestru(78)


# Ten warunek sprawia, że main() uruchomi się tylko wtedy, gdy plik main.py
# zostanie uruchomiony bezpośrednio. Jeśli plik zostanie zaimportowany jako moduł,
# kod wewnątrz tego bloku nie wykona się automatycznie.
if __name__ == "__main__":
    main()
