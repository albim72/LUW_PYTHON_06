"""
employee.py

Moduł zawierający klasę Employee.

Klasa Employee dziedziczy po klasie Person, czyli przejmuje jej podstawowe
atrybuty oraz metody. Następnie rozszerza je o informacje typowe dla pracownika:
stanowisko oraz pensję.
"""

from person import Person


class Employee(Person):
    """
    Klasa reprezentująca pracownika.

    Employee jest klasą potomną klasy Person. Oznacza to, że pracownik jest
    szczególnym rodzajem osoby. Ma imię, nazwisko i wiek, ale dodatkowo posiada
    stanowisko oraz pensję.
    """

    def __init__(
        self,
        first_name: str,
        last_name: str,
        age: int,
        position: str,
        salary: float,
    ) -> None:
        """
        Konstruktor klasy Employee.

        Najpierw wywołuje konstruktor klasy bazowej Person za pomocą super().
        Dzięki temu nie trzeba ponownie pisać kodu odpowiedzialnego za zapisanie
        imienia, nazwiska i wieku. Następnie konstruktor dopisuje dane typowe
        tylko dla pracownika.

        Args:
            first_name: Imię pracownika.
            last_name: Nazwisko pracownika.
            age: Wiek pracownika.
            position: Stanowisko pracownika.
            salary: Pensja pracownika.
        """
        # super() pozwala skorzystać z konstruktora klasy nadrzędnej Person.
        super().__init__(first_name, last_name, age)

        # Atrybuty specyficzne dla klasy Employee.
        self.position = position
        self.salary = salary

    def __str__(self) -> str:
        """
        Zwraca czytelny opis pracownika.

        Metoda __str__ jest podobna do __repr__, ale zwykle służy do tworzenia
        bardziej przyjaznego dla użytkownika opisu obiektu.

        Returns:
            Tekst zawierający dane osobowe, stanowisko i pensję.
        """
        return (
            f"{self.first_name} {self.last_name} -> "
            f"{self.age} lat/a -> {self.position} -> {self.salary}"
        )

    def show_info(self) -> None:
        """
        Wypisuje pełne informacje o pracowniku.

        Metoda nadpisuje metodę show_info z klasy Person. Najpierw wywołuje
        wersję bazową przez super().show_info(), a potem dopisuje dane
        pracownika. To klasyczny przykład rozszerzania metody w dziedziczeniu.
        """
        # Najpierw pokazujemy informacje wspólne dla każdej osoby.
        super().show_info()

        # Następnie dopisujemy informacje właściwe wyłącznie dla pracownika.
        print(f"stanowisko: {self.position}")
        print(f"pensja: {self.salary} zł")

    def work(self) -> None:
        """
        Wypisuje informację o pracy wykonywanej przez pracownika.

        Metoda pokazuje, że obiekt klasy Employee może mieć zachowania, których
        nie posiada zwykły obiekt klasy Person.
        """
        print(
            f"pracownik {self.first_name} {self.last_name} "
            f"pracuje na stanowisku {self.position}"
        )

    def raise_work(self, percent: float) -> float:
        """
        Oblicza pensję po podwyżce procentowej.

        Metoda nie zmienia trwale wartości self.salary. Zwraca tylko wynik
        obliczenia, czyli pensję powiększoną o wskazany procent.

        Args:
            percent: Procent podwyżki, na przykład 15 oznacza 15%.

        Returns:
            Nowa pensja po doliczeniu podwyżki.
        """
        return self.salary + percent * self.salary / 100
