"""
person.py

Moduł bazowy projektu.

Zawiera klasę Person, która reprezentuje ogólną osobę.
Jest to klasa nadrzędna dla bardziej szczegółowych klas, takich jak Employee
oraz Student. Dzięki temu wspólne dane, czyli imię, nazwisko i wiek, są
zdefiniowane tylko raz i mogą być dziedziczone przez klasy potomne.
"""


class Person:
    """
    Klasa reprezentująca podstawową osobę.

    Ta klasa przechowuje dane wspólne dla każdej osoby:
    - imię,
    - nazwisko,
    - wiek.

    Klasa Person pełni w projekcie rolę klasy bazowej. Oznacza to, że inne
    klasy mogą po niej dziedziczyć i rozszerzać jej funkcjonalność o własne
    pola oraz metody.
    """

    def __init__(self, first_name: str, last_name: str, age: int) -> None:
        """
        Konstruktor klasy Person.

        Metoda __init__ uruchamia się automatycznie podczas tworzenia obiektu.
        Przyjmuje dane osoby i zapisuje je w atrybutach obiektu.

        Args:
            first_name: Imię osoby.
            last_name: Nazwisko osoby.
            age: Wiek osoby wyrażony jako liczba całkowita.
        """
        # Atrybuty instancji, czyli dane przypisane do konkretnego obiektu.
        self.first_name = first_name
        self.last_name = last_name
        self.age = age

    def __repr__(self) -> str:
        """
        Zwraca tekstową reprezentację obiektu.

        Metoda specjalna __repr__ jest używana między innymi wtedy, gdy
        przekazujemy obiekt bezpośrednio do funkcji print(). Dzięki niej obiekt
        nie wypisuje się jako techniczny adres w pamięci, tylko jako czytelny
        opis osoby.

        Returns:
            Tekst z imieniem, nazwiskiem i wiekiem osoby.
        """
        return f"{self.first_name} {self.last_name} -> {self.age} lat/a"

    def show_info(self) -> None:
        """
        Wypisuje podstawowe informacje o osobie.

        Metoda nie zwraca wartości. Jej zadaniem jest pokazanie danych
        użytkownikowi w konsoli.
        """
        print(f"imię: {self.first_name}")
        print(f"nazwisko: {self.last_name}")
        print(f"wiek: {self.age}")

    def introduce(self) -> None:
        """
        Wypisuje krótkie przedstawienie osoby.

        Ta metoda pokazuje przykład prostej metody obiektowej, która korzysta
        z danych zapisanych wcześniej w atrybutach instancji.
        """
        print(f"Nazywam się: {self.first_name} {self.last_name}")

    def wiek_za_n_lat(self, n: int) -> int:
        """
        Oblicza wiek osoby za podaną liczbę lat.

        Args:
            n: Liczba lat, którą chcemy dodać do aktualnego wieku.

        Returns:
            Wiek osoby po dodaniu podanej liczby lat.
        """
        return self.age + n
