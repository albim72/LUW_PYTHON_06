# Dokumentacja projektu: Dziedziczenie `Person`, `Employee`, `Student`

## 1. Cel projektu

Projekt pokazuje podstawowe mechanizmy programowania obiektowego w Pythonie na przykładzie klas opisujących osobę, pracownika i studenta.

Główne zagadnienia prezentowane w projekcie:

- definiowanie klas,
- tworzenie konstruktorów `__init__`,
- tworzenie atrybutów obiektu,
- definiowanie metod,
- dziedziczenie klas,
- wywoływanie metod klasy bazowej przez `super()`,
- nadpisywanie metod w klasach potomnych,
- użycie metod specjalnych `__repr__` i `__str__`,
- uruchamianie aplikacji przez funkcję `main()`.

Projekt jest prosty, ale bardzo dobry dydaktycznie, bo pokazuje rdzeń dziedziczenia bez zbędnego hałasu. Mały model, czysta mechanika, żadnego mgłowca frameworków.

---

## 2. Struktura projektu

```text
dziedziczenie_person_documented/
├── main.py
├── person.py
├── employee.py
├── student.py
└── DOKUMENTACJA.md
```

Opis plików:

| Plik | Rola w projekcie |
|---|---|
| `person.py` | Definiuje klasę bazową `Person`. |
| `employee.py` | Definiuje klasę `Employee`, która dziedziczy po `Person`. |
| `student.py` | Definiuje klasę `Student`, która dziedziczy po `Person`. |
| `main.py` | Uruchamia aplikację i pokazuje działanie klas. |
| `DOKUMENTACJA.md` | Dokumentacja projektu. |

---

## 3. Schemat dziedziczenia

```text
        Person
       /      \
 Employee    Student
```

Klasa `Person` jest klasą bazową. Zawiera elementy wspólne dla wszystkich osób.

Klasy `Employee` i `Student` są klasami potomnymi. Dziedziczą po `Person`, ale dodają własne pola i metody.

---

## 4. Moduł `person.py`

Moduł `person.py` zawiera klasę `Person`.

### Klasa `Person`

Klasa `Person` reprezentuje podstawową osobę.

Atrybuty:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `first_name` | `str` | Imię osoby. |
| `last_name` | `str` | Nazwisko osoby. |
| `age` | `int` | Wiek osoby. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `__init__()` | Konstruktor tworzący obiekt osoby. |
| `__repr__()` | Zwraca tekstowy opis osoby. |
| `show_info()` | Wypisuje imię, nazwisko i wiek. |
| `introduce()` | Wypisuje krótkie przedstawienie osoby. |
| `wiek_za_n_lat(n)` | Zwraca wiek osoby za `n` lat. |

Przykład użycia:

```python
person = Person("Jan", "Kowalski", 48)
print(person)
person.show_info()
person.introduce()
print(person.wiek_za_n_lat(5))
```

---

## 5. Moduł `employee.py`

Moduł `employee.py` zawiera klasę `Employee`.

### Klasa `Employee`

Klasa `Employee` dziedziczy po klasie `Person`.

Oznacza to, że obiekt pracownika ma wszystkie podstawowe dane osoby:

- imię,
- nazwisko,
- wiek.

Dodatkowo posiada:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `position` | `str` | Stanowisko pracownika. |
| `salary` | `float` | Pensja pracownika. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `__init__()` | Tworzy pracownika i korzysta z konstruktora `Person`. |
| `__str__()` | Zwraca opis pracownika. |
| `show_info()` | Nadpisuje metodę z `Person` i dodaje stanowisko oraz pensję. |
| `work()` | Wypisuje informację o wykonywanej pracy. |
| `raise_work(percent)` | Oblicza pensję po podwyżce procentowej. |

Najważniejszy fragment:

```python
super().__init__(first_name, last_name, age)
```

Instrukcja `super()` wywołuje konstruktor klasy bazowej `Person`. Dzięki temu nie trzeba przepisywać kodu ustawiającego imię, nazwisko i wiek.

---

## 6. Moduł `student.py`

Moduł `student.py` zawiera klasę `Student`.

### Klasa `Student`

Klasa `Student` również dziedziczy po klasie `Person`.

Student ma dane odziedziczone:

- imię,
- nazwisko,
- wiek.

Dodatkowo posiada:

| Atrybut | Typ | Znaczenie |
|---|---:|---|
| `university` | `str` | Nazwa uczelni. |
| `field_of_study` | `str` | Kierunek studiów. |

Metody:

| Metoda | Znaczenie |
|---|---|
| `__init__()` | Tworzy studenta i korzysta z konstruktora `Person`. |
| `show_info()` | Nadpisuje metodę z `Person` i dodaje uczelnię oraz kierunek studiów. |
| `zaliczenie_semestru(punkty)` | Sprawdza, czy student zdobył minimum 70 punktów. |

Logika zaliczenia:

```text
punkty >= 70  -> semestr zaliczony
punkty < 70   -> brak zaliczenia
```

---

## 7. Moduł `main.py`

Moduł `main.py` jest głównym punktem startowym aplikacji.

Wykonuje następujące kroki:

1. Importuje klasy `Person`, `Employee` i `Student`.
2. Tworzy przykładowy obiekt osoby.
3. Tworzy przykładowy obiekt pracownika.
4. Tworzy przykładowy obiekt studenta.
5. Wywołuje metody pokazujące działanie dziedziczenia.

Fragment startowy:

```python
if __name__ == "__main__":
    main()
```

Ten zapis oznacza, że funkcja `main()` zostanie uruchomiona tylko wtedy, gdy plik `main.py` zostanie uruchomiony bezpośrednio.

---

## 8. Jak uruchomić projekt

W terminalu przejdź do katalogu projektu:

```bash
cd dziedziczenie_person_documented
```

Następnie uruchom:

```bash
python main.py
```

Jeżeli w systemie komenda `python` wskazuje na starszą wersję Pythona, użyj:

```bash
python3 main.py
```

---

## 9. Przykładowy wynik działania

```text
_________ OSOBA __________
Jan Kowalski -> 48 lat/a
imię: Jan
nazwisko: Kowalski
wiek: 48
Nazywam się: Jan Kowalski
wiek za 5 lat: 53 lat/a
_________ PRACOWNIK __________
imię: Anna
nazwisko: Nowak
wiek: 35
stanowisko: Asystentka prezesa
pensja: 8700 zł
Nazywam się: Anna Nowak
pracownik Anna Nowak pracuje na stanowisku Asystentka prezesa
pensja po podwyżce: 10005.0 zł
_________ STUDENT __________
imię: Olaf
nazwisko: Jankowski
wiek: 22
uczelnia: SWPS
kierunek studiów: Sztuczna inteligencja
Nazywam się: Olaf Jankowski
próg zaliczenia -> 70
zaliczenie semestru -> liczba punktów 78
```

---

## 10. Najważniejsze pojęcia obiektowe użyte w projekcie

### Klasa

Klasa jest szablonem do tworzenia obiektów. W projekcie klasami są `Person`, `Employee` i `Student`.

### Obiekt

Obiekt jest konkretną instancją klasy.

Przykład:

```python
person = Person("Jan", "Kowalski", 48)
```

Tutaj `person` jest obiektem klasy `Person`.

### Atrybut

Atrybut przechowuje dane obiektu.

Przykład:

```python
self.first_name = first_name
```

### Metoda

Metoda jest funkcją zdefiniowaną wewnątrz klasy. Operuje na danych obiektu.

### Dziedziczenie

Dziedziczenie pozwala tworzyć klasy potomne na bazie klasy już istniejącej.

Przykład:

```python
class Employee(Person):
    ...
```

Oznacza to, że `Employee` dziedziczy po `Person`.

### Nadpisywanie metod

Klasa potomna może zdefiniować metodę o tej samej nazwie co klasa bazowa. Wtedy jej wersja zastępuje wersję bazową dla obiektów tej klasy.

W projekcie przykładem jest metoda `show_info()` w klasach `Employee` i `Student`.

### `super()`

`super()` pozwala wywołać metodę klasy nadrzędnej.

W projekcie używane jest głównie do wywołania konstruktora `Person` z poziomu `Employee` i `Student`.

---

## 11. Możliwe rozszerzenia projektu

Projekt można łatwo rozbudować o kolejne klasy, na przykład:

- `Teacher`,
- `Manager`,
- `PhDStudent`,
- `Intern`,
- `Contractor`.

Można też dodać:

- walidację wieku,
- walidację pensji,
- zmianę pensji na stałe po podwyżce,
- listę ocen studenta,
- obliczanie średniej ocen,
- zapis danych do pliku JSON,
- testy jednostkowe.

---

## 12. Uwagi dydaktyczne

Ten projekt dobrze nadaje się do pokazania studentom, że dziedziczenie nie jest magicznym zaklęciem, tylko mechanizmem organizowania kodu.

Najważniejsza intuicja:

```text
Employee jest osobą.
Student jest osobą.
Ale nie każda osoba jest pracownikiem albo studentem.
```

Dlatego wspólne cechy umieszczamy w `Person`, a cechy szczegółowe w klasach potomnych.
