"""
student.py

Moduł zawierający klasę Student.

Klasa Student dziedziczy po klasie Person. Dzięki temu student automatycznie
posiada imię, nazwisko, wiek oraz metody zdefiniowane w klasie bazowej.
Moduł rozszerza te informacje o uczelnię, kierunek studiów oraz metodę
sprawdzającą zaliczenie semestru.
"""

from person import Person


class Student(Person):
    """
    Klasa reprezentująca studenta.

    Student jest szczególnym przypadkiem osoby. Oprócz danych podstawowych
    posiada także nazwę uczelni oraz kierunek studiów.
    """

    def __init__(
        self,
        first_name: str,
        last_name: str,
        age: int,
        university: str,
        field_of_study: str,
    ) -> None:
        """
        Konstruktor klasy Student.

        Podobnie jak w klasie Employee, używamy super(), aby nie powielać kodu
        odpowiedzialnego za inicjalizację pól first_name, last_name oraz age.

        Args:
            first_name: Imię studenta.
            last_name: Nazwisko studenta.
            age: Wiek studenta.
            university: Nazwa uczelni.
            field_of_study: Kierunek studiów.
        """
        # Wywołanie konstruktora klasy Person.
        super().__init__(first_name, last_name, age)

        # Atrybuty specyficzne dla studenta.
        self.university = university
        self.field_of_study = field_of_study

    def show_info(self) -> None:
        """
        Wypisuje pełne informacje o studencie.

        Metoda nadpisuje show_info z klasy Person. Najpierw korzysta z metody
        klasy bazowej, aby wypisać dane osobowe, a potem dodaje informacje
        dotyczące studiów.
        """
        # Informacje odziedziczone z klasy Person.
        super().show_info()

        # Informacje dodane w klasie Student.
        print(f"uczelnia: {self.university}")
        print(f"kierunek studiów: {self.field_of_study}")

    def zaliczenie_semestru(self, punkty: int) -> None:
        """
        Sprawdza, czy student zaliczył semestr.

        W tym uproszczonym przykładzie próg zaliczenia wynosi 70 punktów.
        Jeżeli liczba punktów jest większa lub równa 70, semestr zostaje
        zaliczony. W przeciwnym wypadku student nie uzyskuje zaliczenia.

        Args:
            punkty: Liczba punktów zdobytych przez studenta.
        """
        prog_zaliczenia = 70

        print(f"próg zaliczenia -> {prog_zaliczenia}")

        if punkty >= prog_zaliczenia:
            print(f"zaliczenie semestru -> liczba punktów {punkty}")
        else:
            print(f"brak zaliczenia semestru -> liczba punktów {punkty}")
