import csv
from pathlib import Path

from wniosek_emerytalny import WniosekEmerytalny
from wniosek_rentowy import WniosekRentowy
from wniosek_zasilkowy import WniosekZasilkowy


NAGLOWKI_CSV = [
    "typ_wniosku",
    "numer_sprawy",
    "imie",
    "nazwisko",
    "pesel",
    "status",
    "lata_pracy",
    "stopien_niezdolnosci",
    "liczba_dni_zwolnienia",
]


def pokaz_wszystkie_sprawy(lista_spraw):
    """
    Wyświetla dane wszystkich spraw przekazanych na liście.
    """
    for sprawa in lista_spraw:
        print("=" * 60)
        print(sprawa.pokaz_dane())
        print(f"Opis: {sprawa.opis_sprawy()}")
        print(f"Przewidywany czas obsługi: {sprawa.oblicz_czas_obslugi()} dni")


def policz_laczny_czas_obslugi(lista_spraw):
    """
    Zwraca łączny przewidywany czas obsługi wszystkich spraw.
    """
    return sum(sprawa.oblicz_czas_obslugi() for sprawa in lista_spraw)


def sprawa_na_slownik(sprawa):
    """
    Zamienia obiekt sprawy na słownik zgodny z nagłówkami pliku CSV.
    """
    dane = {
        "typ_wniosku": sprawa.typ_wniosku(),
        "numer_sprawy": sprawa.numer_sprawy,
        "imie": sprawa.imie,
        "nazwisko": sprawa.nazwisko,
        "pesel": sprawa.pesel,
        "status": sprawa.status,
        "lata_pracy": "",
        "stopien_niezdolnosci": "",
        "liczba_dni_zwolnienia": "",
    }

    if isinstance(sprawa, WniosekEmerytalny):
        dane["lata_pracy"] = sprawa.lata_pracy
    elif isinstance(sprawa, WniosekRentowy):
        dane["stopien_niezdolnosci"] = sprawa.stopien_niezdolnosci
    elif isinstance(sprawa, WniosekZasilkowy):
        dane["liczba_dni_zwolnienia"] = sprawa.liczba_dni_zwolnienia

    return dane


def zapisz_archiwum_txt(lista_spraw, nazwa_pliku):
    """
    Zapisuje tekstowe archiwum spraw do pliku TXT.
    """
    sciezka = Path(nazwa_pliku)
    sciezka.parent.mkdir(parents=True, exist_ok=True)

    with sciezka.open("w", encoding="utf-8") as plik:
        plik.write("ARCHIWUM SPRAW ZUS\n")
        plik.write("=" * 60 + "\n\n")

        for sprawa in lista_spraw:
            plik.write(f"Numer sprawy: {sprawa.numer_sprawy}\n")
            plik.write(f"Imię: {sprawa.imie}\n")
            plik.write(f"Nazwisko: {sprawa.nazwisko}\n")
            plik.write(f"PESEL: {sprawa.pesel}\n")
            plik.write(f"Status: {sprawa.status}\n")
            plik.write(f"Opis: {sprawa.opis_sprawy()}\n")
            plik.write(f"Przewidywany czas obsługi: {sprawa.oblicz_czas_obslugi()} dni\n")
            plik.write("-" * 60 + "\n")


def zapisz_sprawy_csv(lista_spraw, nazwa_pliku):
    """
    Zapisuje listę spraw do pliku CSV.

    Używamy separatora średnik, bo taki format jest wygodny dla polskiego Excela.
    Używamy kodowania utf-8-sig, żeby polskie znaki otwierały się poprawnie.
    """
    sciezka = Path(nazwa_pliku)
    sciezka.parent.mkdir(parents=True, exist_ok=True)

    with sciezka.open("w", encoding="utf-8-sig", newline="") as plik:
        writer = csv.DictWriter(plik, fieldnames=NAGLOWKI_CSV, delimiter=";")
        writer.writeheader()

        for sprawa in lista_spraw:
            writer.writerow(sprawa_na_slownik(sprawa))


def utworz_sprawe_z_wiersza(wiersz):
    """
    Tworzy odpowiedni obiekt sprawy na podstawie jednego wiersza z pliku CSV.
    """
    typ = wiersz["typ_wniosku"].strip().lower()

    wspolne_dane = {
        "numer_sprawy": wiersz["numer_sprawy"].strip(),
        "imie": wiersz["imie"].strip(),
        "nazwisko": wiersz["nazwisko"].strip(),
        "pesel": wiersz["pesel"].strip(),
        "status": wiersz["status"].strip(),
    }

    if typ == "emerytalny":
        return WniosekEmerytalny(
            **wspolne_dane,
            lata_pracy=int(wiersz["lata_pracy"]),
        )

    if typ == "rentowy":
        return WniosekRentowy(
            **wspolne_dane,
            stopien_niezdolnosci=wiersz["stopien_niezdolnosci"].strip(),
        )

    if typ == "zasilkowy":
        return WniosekZasilkowy(
            **wspolne_dane,
            liczba_dni_zwolnienia=int(wiersz["liczba_dni_zwolnienia"]),
        )

    raise ValueError(f"Nieznany typ wniosku: {typ}")


def wczytaj_sprawy_csv(nazwa_pliku, pomin_bledne=True):
    """
    Odczytuje sprawy z pliku CSV i zwraca listę obiektów.

    Parametr pomin_bledne:
    - True: błędne rekordy są pomijane, a informacja trafia do konsoli,
    - False: pierwszy błąd przerywa działanie programu.
    """
    sciezka = Path(nazwa_pliku)

    if not sciezka.exists():
        raise FileNotFoundError(f"Nie znaleziono pliku: {nazwa_pliku}")

    lista_spraw = []

    with sciezka.open("r", encoding="utf-8-sig", newline="") as plik:
        reader = csv.DictReader(plik, delimiter=";")

        for numer_wiersza, wiersz in enumerate(reader, start=2):
            try:
                sprawa = utworz_sprawe_z_wiersza(wiersz)
                lista_spraw.append(sprawa)
            except Exception as blad:
                if pomin_bledne:
                    print(f"Pominięto wiersz {numer_wiersza}: {blad}")
                else:
                    raise

    return lista_spraw


def policz_sprawy_wedlug_typu(lista_spraw):
    """
    Zlicza sprawy według typu wniosku.
    """
    wynik = {}

    for sprawa in lista_spraw:
        typ = sprawa.typ_wniosku()
        wynik[typ] = wynik.get(typ, 0) + 1

    return wynik


def filtruj_sprawy_po_statusie(lista_spraw, status):
    """
    Zwraca listę spraw o podanym statusie.
    """
    return [sprawa for sprawa in lista_spraw if sprawa.status == status]


def sortuj_sprawy_po_czasie_obslugi(lista_spraw, malejaco=False):
    """
    Zwraca nową listę spraw posortowaną według przewidywanego czasu obsługi.
    """
    return sorted(
        lista_spraw,
        key=lambda sprawa: sprawa.oblicz_czas_obslugi(),
        reverse=malejaco,
    )


def zapisz_osobne_pliki_csv_dla_typow(lista_spraw, katalog_wynikowy):
    """
    Zapisuje osobne pliki CSV dla każdego typu wniosku.
    """
    katalog = Path(katalog_wynikowy)
    katalog.mkdir(parents=True, exist_ok=True)

    typy = {
        "emerytalny": [],
        "rentowy": [],
        "zasilkowy": [],
    }

    for sprawa in lista_spraw:
        typy[sprawa.typ_wniosku()].append(sprawa)

    for typ, sprawy in typy.items():
        zapisz_sprawy_csv(sprawy, katalog / f"wnioski_{typ}.csv")
