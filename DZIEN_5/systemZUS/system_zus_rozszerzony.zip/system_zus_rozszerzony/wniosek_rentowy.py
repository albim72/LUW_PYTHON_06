from sprawazus import SprawaZUS


class WniosekRentowy(SprawaZUS):
    """
    Wniosek rentowy.

    Dodatkowe pole:
    - stopien_niezdolnosci
    """

    DOZWOLONE_STOPNIE = ("częściowa", "całkowita")

    def __init__(self, numer_sprawy, imie, nazwisko, pesel, status, stopien_niezdolnosci):
        super().__init__(numer_sprawy, imie, nazwisko, pesel, status)
        self.stopien_niezdolnosci = stopien_niezdolnosci

        if self.stopien_niezdolnosci not in self.DOZWOLONE_STOPNIE:
            raise ValueError(
                f"Niepoprawny stopień niezdolności: {self.stopien_niezdolnosci}. "
                f"Dozwolone wartości: {', '.join(self.DOZWOLONE_STOPNIE)}"
            )

    def oblicz_czas_obslugi(self):
        if self.stopien_niezdolnosci == "całkowita":
            return 21
        return 35

    def opis_sprawy(self):
        return (
            f"Wniosek rentowy osoby: {self.imie} {self.nazwisko}. "
            f"Stopień niezdolności do pracy: {self.stopien_niezdolnosci}."
        )

    def typ_wniosku(self):
        return "rentowy"
