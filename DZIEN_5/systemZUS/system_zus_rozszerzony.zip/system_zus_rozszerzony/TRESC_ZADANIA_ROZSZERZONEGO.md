# Zadanie rozszerzone: System obsługi spraw ZUS, archiwum TXT i pliki CSV

## Kontekst

Masz już projekt `System obsługi spraw ZUS`, który zawiera:

- klasę abstrakcyjną `SprawaZUS`,
- trzy klasy dziedziczące:
  - `WniosekEmerytalny`,
  - `WniosekRentowy`,
  - `WniosekZasilkowy`,
- funkcje zewnętrzne do pracy z listą spraw.

Teraz rozbuduj projekt o trwały zapis danych do plików.

---

## Cel zadania

Celem zadania jest przećwiczenie:

- zapisu danych do pliku TXT,
- zapisu danych do pliku CSV,
- odczytu danych z pliku CSV,
- tworzenia obiektów na podstawie danych z pliku,
- pracy z listą obiektów,
- obsługi błędów,
- filtrowania i sortowania danych.

---

## Punkt 1. Archiwum tekstowe TXT

Utwórz funkcję:

```python
zapisz_archiwum_txt(lista_spraw, nazwa_pliku)
```

Funkcja ma zapisać dane wszystkich spraw do pliku tekstowego.

W pliku powinny znaleźć się:

- numer sprawy,
- imię,
- nazwisko,
- PESEL,
- status,
- opis sprawy,
- przewidywany czas obsługi.

---

## Punkt 2. Eksport spraw do pliku CSV

Utwórz funkcję:

```python
zapisz_sprawy_csv(lista_spraw, nazwa_pliku)
```

Funkcja ma zapisać listę spraw do pliku CSV.

Plik CSV powinien zawierać kolumny:

```text
typ_wniosku
numer_sprawy
imie
nazwisko
pesel
status
lata_pracy
stopien_niezdolnosci
liczba_dni_zwolnienia
```

Dla danego typu wniosku część pól może być pusta.

---

## Punkt 3. Odczyt wniosków z pliku CSV

Utwórz funkcję:

```python
wczytaj_sprawy_csv(nazwa_pliku)
```

Funkcja ma odczytać dane z pliku CSV i utworzyć odpowiednie obiekty:

- `emerytalny` → `WniosekEmerytalny`,
- `rentowy` → `WniosekRentowy`,
- `zasilkowy` → `WniosekZasilkowy`.

Funkcja powinna zwrócić listę obiektów.

---

## Punkt 4. Funkcje dodatkowe

Dopisz funkcje:

```python
policz_sprawy_wedlug_typu(lista_spraw)
filtruj_sprawy_po_statusie(lista_spraw, status)
sortuj_sprawy_po_czasie_obslugi(lista_spraw, malejaco=False)
zapisz_osobne_pliki_csv_dla_typow(lista_spraw, katalog_wynikowy)
```

---

## Punkt 5. Wymagania dla pliku CSV

Plik CSV używa:

- kodowania `utf-8-sig`,
- separatora `;`.

Do odczytu użyj:

```python
csv.DictReader(plik, delimiter=";")
```

Do zapisu użyj:

```python
csv.DictWriter(plik, fieldnames=naglowki, delimiter=";")
```

---

## Punkt 6. Wymagania końcowe programu

W pliku `main.py` wykonaj:

1. Wczytaj listę spraw z pliku `dane/wnioski_zus_30.csv`.
2. Wyświetl wszystkie sprawy.
3. Oblicz łączny czas obsługi wszystkich spraw.
4. Policz sprawy według typu.
5. Przefiltruj sprawy po statusie `nowa`.
6. Posortuj sprawy według czasu obsługi.
7. Zmień status kilku wybranych spraw.
8. Zapisz archiwum TXT do katalogu `wyniki`.
9. Zapisz eksport CSV po zmianach.
10. Zapisz osobne pliki CSV dla każdego typu wniosku.

---

## Efekt końcowy

Po wykonaniu zadania program powinien potrafić:

- wczytać sprawy ZUS z pliku CSV,
- utworzyć odpowiednie obiekty,
- pracować na liście obiektów,
- obliczyć czas obsługi,
- zapisać archiwum tekstowe,
- wyeksportować dane do pliku CSV,
- utworzyć osobne pliki CSV dla różnych typów wniosków.
