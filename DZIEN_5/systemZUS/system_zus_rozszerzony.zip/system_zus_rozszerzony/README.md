# System obsługi spraw ZUS, wersja rozszerzona

Projekt szkoleniowy z Pythona pokazujący:

- klasę abstrakcyjną,
- dziedziczenie,
- metody abstrakcyjne,
- metodę statyczną,
- metodę klasy,
- funkcje zewnętrzne,
- zapis do TXT,
- zapis do CSV,
- odczyt z CSV,
- filtrowanie, sortowanie i proste statystyki.

## Struktura projektu

```text
system_zus_rozszerzony/
├── dane/
│   └── wnioski_zus_30.csv
├── wyniki/
├── sprawazus.py
├── wniosek_emerytalny.py
├── wniosek_rentowy.py
├── wniosek_zasilkowy.py
├── wniosek_funkcje.py
├── main.py
├── TRESC_ZADANIA_ROZSZERZONEGO.md
└── README.md
```

## Jak uruchomić

W terminalu przejdź do katalogu projektu i wpisz:

```bash
python main.py
```

Program wczyta dane z pliku:

```text
dane/wnioski_zus_30.csv
```

i zapisze wyniki do katalogu:

```text
wyniki/
```

## Pliki wynikowe

Po uruchomieniu programu powstaną między innymi:

```text
wyniki/archiwum_spraw.txt
wyniki/eksport_spraw_po_zmianach.csv
wyniki/wnioski_emerytalny.csv
wyniki/wnioski_rentowy.csv
wyniki/wnioski_zasilkowy.csv
```

## Uwaga dydaktyczna

To zadanie dobrze pokazuje moment, w którym klasy przestają być abstrakcyjną dekoracją,
a zaczynają pracować jako model danych w małym systemie.
