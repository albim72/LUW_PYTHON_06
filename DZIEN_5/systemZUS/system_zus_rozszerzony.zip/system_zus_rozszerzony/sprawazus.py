from abc import ABC, abstractmethod
from datetime import date


class SprawaZUS(ABC):
    """
    Klasa abstrakcyjna reprezentująca wspólny szablon sprawy ZUS.

    Nie tworzymy obiektów tej klasy bezpośrednio.
    Tworzymy obiekty klas potomnych, np. WniosekEmerytalny,
    WniosekRentowy albo WniosekZasilkowy.
    """

    licznik_spraw = 0
    DOZWOLONE_STATUSY = ("nowa", "w trakcie", "zakończona")

    def __init__(self, numer_sprawy, imie, nazwisko, pesel, status="nowa"):
        self.numer_sprawy = numer_sprawy
        self.imie = imie
        self.nazwisko = nazwisko
        self.pesel = pesel
        self.status = status
        self._sprawdz_podstawowe_dane()

    def _sprawdz_podstawowe_dane(self):
        """
        Prosta walidacja danych wspólnych dla wszystkich spraw.
        """
        if not self.czy_poprawny_pesel(self.pesel):
            raise ValueError(f"Niepoprawny PESEL: {self.pesel}")

        if self.status not in self.DOZWOLONE_STATUSY:
            raise ValueError(
                f"Niepoprawny status: {self.status}. "
                f"Dozwolone statusy: {', '.join(self.DOZWOLONE_STATUSY)}"
            )

    def zmien_status(self, nowy_status):
        """
        Zmienia status sprawy po sprawdzeniu, czy status jest poprawny.
        """
        if nowy_status not in self.DOZWOLONE_STATUSY:
            raise ValueError(
                f"Niepoprawny status: {nowy_status}. "
                f"Dozwolone statusy: {', '.join(self.DOZWOLONE_STATUSY)}"
            )

        self.status = nowy_status

    def pokaz_dane(self):
        """
        Zwraca podstawowe dane sprawy jako tekst.
        """
        return (
            f"Numer sprawy: {self.numer_sprawy}\n"
            f"Imię: {self.imie}\n"
            f"Nazwisko: {self.nazwisko}\n"
            f"PESEL: {self.pesel}\n"
            f"Status: {self.status}"
        )

    def typ_wniosku(self):
        """
        Zwraca techniczną nazwę typu wniosku używaną w plikach CSV.
        """
        return self.__class__.__name__

    @abstractmethod
    def oblicz_czas_obslugi(self):
        """
        Zwraca przewidywany czas obsługi sprawy w dniach.
        Każda klasa potomna musi zaimplementować tę metodę po swojemu.
        """
        pass

    @abstractmethod
    def opis_sprawy(self):
        """
        Zwraca opis konkretnego typu sprawy.
        Każda klasa potomna musi zaimplementować tę metodę po swojemu.
        """
        pass

    @staticmethod
    def czy_poprawny_pesel(pesel):
        """
        Sprawdza uproszczoną poprawność numeru PESEL.

        W tej wersji sprawdzamy tylko:
        - czy PESEL jest tekstem,
        - czy ma 11 znaków,
        - czy składa się wyłącznie z cyfr.
        """
        return isinstance(pesel, str) and len(pesel) == 11 and pesel.isdigit()

    @classmethod
    def utworz_numer_sprawy(cls):
        """
        Generuje kolejny numer sprawy.
        """
        cls.licznik_spraw += 1
        return f"ZUS/{cls.licznik_spraw}/{date.today().year}"
