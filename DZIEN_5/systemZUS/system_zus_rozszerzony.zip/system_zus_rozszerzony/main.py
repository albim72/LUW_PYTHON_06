from pathlib import Path

from sprawazus import SprawaZUS
from wniosek_funkcje import (
    filtruj_sprawy_po_statusie,
    pokaz_wszystkie_sprawy,
    policz_laczny_czas_obslugi,
    policz_sprawy_wedlug_typu,
    sortuj_sprawy_po_czasie_obslugi,
    wczytaj_sprawy_csv,
    zapisz_archiwum_txt,
    zapisz_osobne_pliki_csv_dla_typow,
    zapisz_sprawy_csv,
)


PLIK_WEJSCIOWY = Path("dane") / "wnioski_zus_30.csv"
KATALOG_WYNIKOW = Path("wyniki")


def main():
    print("SYSTEM OBSŁUGI SPRAW ZUS")
    print("=" * 60)

    # 1. Wczytanie spraw z pliku CSV.
    lista_spraw = wczytaj_sprawy_csv(PLIK_WEJSCIOWY)
    print(f"Wczytano liczbę spraw: {len(lista_spraw)}")

    # 2. Wyświetlenie wszystkich spraw.
    print("\nLISTA WSZYSTKICH SPRAW")
    pokaz_wszystkie_sprawy(lista_spraw)

    # 3. Łączny czas obsługi.
    laczny_czas = policz_laczny_czas_obslugi(lista_spraw)
    print(f"\nŁączny czas obsługi wszystkich spraw: {laczny_czas} dni")

    # 4. Statystyka według typu wniosku.
    print("\nLICZBA SPRAW WEDŁUG TYPU")
    statystyka = policz_sprawy_wedlug_typu(lista_spraw)
    for typ, liczba in statystyka.items():
        print(f"{typ}: {liczba}")

    # 5. Filtrowanie po statusie.
    sprawy_nowe = filtruj_sprawy_po_statusie(lista_spraw, "nowa")
    print(f"\nLiczba spraw ze statusem 'nowa': {len(sprawy_nowe)}")

    # 6. Sortowanie według czasu obsługi.
    sprawy_posortowane = sortuj_sprawy_po_czasie_obslugi(lista_spraw, malejaco=True)
    print("\nTRZY SPRAWY O NAJDŁUŻSZYM CZASIE OBSŁUGI")
    for sprawa in sprawy_posortowane[:3]:
        print(
            f"{sprawa.numer_sprawy}: {sprawa.imie} {sprawa.nazwisko}, "
            f"czas: {sprawa.oblicz_czas_obslugi()} dni"
        )

    # 7. Zmiana statusu kilku spraw.
    lista_spraw[0].zmien_status("zakończona")
    lista_spraw[1].zmien_status("zakończona")
    lista_spraw[2].zmien_status("w trakcie")

    # 8. Sprawdzenie PESEL metodą statyczną.
    testowy_pesel = "80010112345"
    print(f"\nCzy PESEL {testowy_pesel} jest poprawny? {SprawaZUS.czy_poprawny_pesel(testowy_pesel)}")

    # 9. Wygenerowanie przykładowego numeru sprawy metodą klasy.
    print(f"Przykładowy nowy numer sprawy: {SprawaZUS.utworz_numer_sprawy()}")

    # 10. Zapisywanie wyników do plików.
    KATALOG_WYNIKOW.mkdir(exist_ok=True)

    zapisz_archiwum_txt(lista_spraw, KATALOG_WYNIKOW / "archiwum_spraw.txt")
    zapisz_sprawy_csv(lista_spraw, KATALOG_WYNIKOW / "eksport_spraw_po_zmianach.csv")
    zapisz_osobne_pliki_csv_dla_typow(lista_spraw, KATALOG_WYNIKOW)

    print("\nZapisano pliki wynikowe w katalogu 'wyniki'.")


if __name__ == "__main__":
    main()
